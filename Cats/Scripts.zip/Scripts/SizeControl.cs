﻿using UnityEngine;
using System.Collections;

public class SizeControl : MonoBehaviour {


	//public float scale;

	// Use this for initialization



	void Start () {
//		scale = 0.3f;
//		transform.localScale.x = scale;
//		transform.localScale.y = scale;
//		transform.localScale.z = scale;
	}
	
	// Update is called once per frame
	void FixedUpdate () {

	
	}
}
